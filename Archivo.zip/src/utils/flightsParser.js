function parsingFlights(values) {
  const dateAndTime;
}
